package com.example.myapplication;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.util.ArrayList;

public class WorkoutService extends Service {

    public static final String CHANNEL_ID = "WorkoutChannel";
    private ArrayList<String> nomes;
    private ArrayList<Integer> tempos;
    private int index = 0;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nomes = intent.getStringArrayListExtra("nomes");
        tempos = intent.getIntegerArrayListExtra("tempos");

        criarCanalNotificacao();
        iniciarExercicio();

        return START_NOT_STICKY;
    }

    private void iniciarExercicio() {
        if (index >= nomes.size()) {
            enviarNotificacao("Treino concluído! Parabéns!");
            stopSelf();
            return;
        }

        String nomeAtual = nomes.get(index);
        int duracao = tempos.get(index) * 1000;

        enviarNotificacao("Iniciando: " + nomeAtual);

        new CountDownTimer(duracao, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                index++;
                iniciarExercicio();
            }
        }.start();
    }

    private void enviarNotificacao(String texto) {
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Treino em Andamento")
                .setContentText(texto)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();

        startForeground(1, notification);
    }

    private void criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel canal = new NotificationChannel(
                    CHANNEL_ID,
                    "Canal de Treino",
                    NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(canal);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
