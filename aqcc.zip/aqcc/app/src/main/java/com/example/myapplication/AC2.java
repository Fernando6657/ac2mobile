package com.example.myapplication;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class AC2 extends Activity {

    public static ArrayList<Exercicio> exercicios;
    EditText editNome, editTempo;
    Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ac2);

        editNome = findViewById(R.id.editNome);
        editTempo = findViewById(R.id.editTempo);
        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editNome.getText().toString();
                int tempo = Integer.parseInt(editTempo.getText().toString());


                Intent intent = new Intent();
                intent.putExtra("nome", nome);
                intent.putExtra("tempo", tempo);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}

