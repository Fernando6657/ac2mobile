package com.example.myapplication;


import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ExecucaoTreinoActivity extends AppCompatActivity {

    private TextView txtExercicioAtual, txtContagemRegressiva;
    private int tempoRestante = 30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_execucao_treino);

        txtExercicioAtual = findViewById(R.id.txtExercicioAtual);
        txtContagemRegressiva = findViewById(R.id.txtContagemRegressiva);


        txtExercicioAtual.setText("Agachamento");


        iniciarContagemRegressiva();
    }

    private void iniciarContagemRegressiva() {
        new CountDownTimer(tempoRestante * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                txtContagemRegressiva.setText("Tempo restante: " + millisUntilFinished / 1000);
            }

            @Override
            public void onFinish() {
                txtContagemRegressiva.setText("Exercício concluído!");

            }
        }.start();
    }
}
